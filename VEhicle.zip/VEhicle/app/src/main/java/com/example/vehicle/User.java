package com.example.vehicle;

public class User {
    private String userid;
    private String username;

    public User(String userid, String username, String useremail, String usermobileno,String usermake) {
        this.userid = userid;
        this.username = username;
        this.useremail = useremail;
        this.usermobileno = usermobileno;
        this.usermake=usermake;
    }

    private String useremail;
    private String usermake;

    private String usermobileno;

    public User() {

    }

    public String getUsermake() {
        return usermake;
    }

    public void setUsermake(String usermake) {
        this.usermake = usermake;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public String getUsermobileno() {
        return usermobileno;
    }

    public void setUsermobileno(String usermobileno) {
        this.usermobileno = usermobileno;
    }



}